<footer id="footer" class="footer dark-background">

<div class="container footer-top">
  <div class="row gy-4">
    <div class="col-lg-4 col-md-6 footer-about">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo briko.png" alt="Gutz Logo">
      </a>
      <div class="footer-contact pt-3">
        <p>OutXource is a US-based property management team providing Property Managers with accounting and bookkeeping, administrative assistance, and social media management services. The company is registered in the Philippines in its legal name – Navor Bataque & Co. CPA’s doing business under OutXource.</p>
        <p class="mt-3"><strong>Phone:</strong> <span>056-311-9677</span></p>
        <p><strong>Email:</strong> <span>official@onlinegutz.com</span></p>
      </div>
      <div class="social-links d-flex mt-4">
        <a href=""><i class="bi bi-twitter-x"></i></a>
        <a href=""><i class="bi bi-facebook"></i></a>
        <a href=""><i class="bi bi-instagram"></i></a>
        <a href=""><i class="bi bi-linkedin"></i></a>
      </div>
    </div>

    <div class="col-lg-2 col-md-3 footer-links">
      <h4>Useful Links</h4>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About us</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="#">Terms of service</a></li>
        <li><a href="#">Privacy policy</a></li>
      </ul>
    </div>

    <div class="col-lg-2 col-md-3 footer-links">
      <h4>Our Services</h4>
      <ul>
        <li><a href="#">Virtual Assistance</a></li>
        <li><a href="#">Virtual Property Management</a></li>
      </ul>
    </div>

    <div class="col-lg-4 col-md-12 footer-newsletter">
      <h4>Our Newsletter</h4>
      <p>Get exclusive access to our latest news and updates here at OutXource. We provide regular and limited sneak peeks to our latest promos and releases right in your inbox. Subscribe now.</p>
      <form action="forms/newsletter.php" method="post" class="php-email-form">
        <div class="newsletter-form"><input type="email" name="email"><input type="submit" value="Subscribe"></div>
        <div class="loading">Loading</div>
        <div class="error-message"></div>
        <div class="sent-message">Your subscription request has been sent. Thank you!</div>
      </form>
    </div>

  </div>
</div>

<div class="container copyright text-center mt-4">
  <p>© <span>Copyright</span> <strong class="px-1 sitename">2025</strong> <span>All Rights Reserved</span></p>
  <div class="credits">
    Web Developer: <a href="">Diether M. Estadula</a>
  </div>
</div>

</footer>